import 'package:ehjez_admin/constants.dart';
import 'package:ehjez_admin/providers/providers.dart';
import 'package:ehjez_admin/screens/auth/login_screen.dart';
import 'package:ehjez_admin/screens/vacation_days_screen.dart';
import 'package:ehjez_admin/widgets/court_assignment_board.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class ReservationsScreen extends ConsumerWidget {
  const ReservationsScreen({super.key});

  void _signOut(BuildContext context) async {
    await Supabase.instance.client.auth.signOut();
    if (!context.mounted) return;
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (_) => LoginScreen()),
    );
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final courtAsync = ref.watch(currentCourtProvider);

    return Scaffold(
      appBar: AppBar(
        title: courtAsync.whenData((c) => c.name).value != null
            ? Text(courtAsync.value!.name)
            : const Text('Reservations'),
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: () => _signOut(context),
          ),
        ],
      ),
      body: courtAsync.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => Center(
          child: Text(
            'Error loading court: $e',
            style: const TextStyle(color: Colors.red, fontSize: 16),
            textAlign: TextAlign.center,
          ),
        ),
        data: (court) => Padding(
          padding: const EdgeInsets.all(24),
          child: CourtAssignmentBoard(
            courtId: court.id,
            courtName: court.name,
            courtStartTime: court.startTime ?? '08:00:00',
            courtEndTime: court.endTime ?? '23:00:00',
          ),
        ),
      ),
      // Vacation days button fixed at the bottom
      bottomNavigationBar: courtAsync.whenData((c) => c.id).value != null
          ? SafeArea(
              child: Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                child: SizedBox(
                  height: 48,
                  child: ElevatedButton.icon(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => VacationDaysScreen(
                            courtId: courtAsync.value!.id,
                          ),
                        ),
                      );
                    },
                    icon: const Icon(Icons.beach_access_outlined, size: 18),
                    label: const Text('Manage Vacation Days'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.orange.shade600,
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      elevation: 2,
                    ),
                  ),
                ),
              ),
            )
          : null,
    );
  }
}
